#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

class Account {
private:
    char accountNumber[20];
    char firstName[10];
    char lastName[10];
    float totalBalance;

public:
    void readData();
    void showData();
    void writeRecord();
    void readRecords();
    void searchRecord();
    void editRecord();
    void deleteRecord();
};

void Account::readData() {
    cout << "Enter Account Number: ";
    cin >> accountNumber;
    cout << "Enter First Name: ";
    cin >> firstName;
    cout << "Enter Last Name: ";
    cin >> lastName;
    cout << "Enter Balance: ";
    cin >> totalBalance;
    cout << endl;
}

void Account::showData() {
    cout << "Account Number: " << accountNumber << endl;
    cout << "First Name: " << firstName << endl;
    cout << "Last Name: " << lastName << endl;
    cout << "Current Balance: Rs. " << totalBalance << endl;
    cout << "-------------------------------" << endl;
}

void Account::writeRecord() {
    ofstream outfile("record.bank", ios::binary | ios::app);
    readData();
    outfile.write(reinterpret_cast<char*>(this), sizeof(*this));
    outfile.close();
}

void Account::readRecords() {
    ifstream infile("record.bank", ios::binary);
    if (!infile) {
        cout << "Error in Opening! File Not Found!!" << endl;
        return;
    }

    cout << "\n****Data from file****" << endl;
    while (infile.read(reinterpret_cast<char*>(this), sizeof(*this))) {
        showData();
    }

    infile.close();
}

void Account::searchRecord() {
    int n;
    ifstream infile("record.bank", ios::binary);
    if (!infile) {
        cout << "\nError in opening! File Not Found!!" << endl;
        return;
    }

    infile.seekg(0, ios::end);
    int count = infile.tellg() / sizeof(*this);
    cout << "\nThere are " << count << " records in the file";
    cout << "\nEnter Record Number to Search: ";
    cin >> n;

    infile.seekg((n - 1) * sizeof(*this));
    infile.read(reinterpret_cast<char*>(this), sizeof(*this));
    showData();
}

void Account::editRecord() {
    int n;
    fstream iofile("record.bank", ios::in | ios::out | ios::binary);
    if (!iofile) {
        cout << "\nError in opening! File Not Found!!" << endl;
        return;
    }

    iofile.seekg(0, ios::end);
    int count = iofile.tellg() / sizeof(*this);
    cout << "\nThere are " << count << " records in the file";
    cout << "\nEnter Record Number to edit: ";
    cin >> n;

    iofile.seekg((n - 1) * sizeof(*this));
    iofile.read(reinterpret_cast<char*>(this), sizeof(*this));

    cout << "Record " << n << " has the following data" << endl;
    showData();

    iofile.close();
    iofile.open("record.bank", ios::out | ios::in | ios::binary);
    iofile.seekp((n - 1) * sizeof(*this));

    cout << "\nEnter data to Modify" << endl;
    readData();
    iofile.write(reinterpret_cast<char*>(this), sizeof(*this));
}

void Account::deleteRecord() {
    int n;
    ifstream infile("record.bank", ios::binary);
    if (!infile) {
        cout << "\nError in opening! File Not Found!!" << endl;
        return;
    }

    infile.seekg(0, ios::end);
    int count = infile.tellg() / sizeof(*this);
    cout << "\nThere are " << count << " records in the file";
    cout << "\nEnter Record Number to Delete: ";
    cin >> n;

    fstream tmpfile("tmpfile.bank", ios::out | ios::binary);
    infile.seekg(0);

    for (int i = 0; i < count; i++) {
        infile.read(reinterpret_cast<char*>(this), sizeof(*this));
        if (i == (n - 1))
            continue;
        tmpfile.write(reinterpret_cast<char*>(this), sizeof(*this));
    }

    infile.close();
    tmpfile.close();
    remove("record.bank");
    rename("tmpfile.bank", "record.bank");
}

int main() {
    Account account;

    while (true) {
        int choice;
        cout << "***Account Information System***" << endl;
        cout << "Select one option below:" << endl;
        cout << "\t1-->Add record to file" << endl;
        cout << "\t2-->Show record from file" << endl;
        cout << "\t3-->Search Record from file" << endl;
        cout << "\t4-->Update Record" << endl;
        cout << "\t5-->Delete Record" << endl;
        cout << "\t6-->Quit" << endl;
        cout<<endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                account.writeRecord();
                break;
            case 2:
                account.readRecords();
                break;
            case 3:
                account.searchRecord();
                break;
            case 4:
                account.editRecord();
                break;
            case 5:
                account.deleteRecord();
                break;
            case 6:
                exit(0);
            default:
                cout << "Enter correct choice" << endl;
                exit(0);
        }
    }

    return 0;
}
